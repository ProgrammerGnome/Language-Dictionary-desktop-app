package BackEnd_layer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class RandomWord {
    
    public void RandomF() throws FileNotFoundException {
        int min = 1;
        int max = 0;
        Scanner scanner = new Scanner(new File("system_files/c_variable.txt"));
                while(scanner.hasNextInt())
                {
                    max = scanner.nextInt();
                }
        int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
        //System.out.println("This is a random integer: "+random_int);
        
        try {
            File file = new File("program_database_dict.xml");
            try (FileWriter output = new FileWriter("system_files/db_to_scr.txt")) {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(file);
                doc.getDocumentElement().normalize();
                //System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
                
                NodeList nodeList = doc.getElementsByTagName("registration");
                for (int itr = 0; itr < nodeList.getLength(); itr++) {
                    Node node = nodeList.item(itr);
                    //System.out.println("\nNode Name :" + node.getNodeName());
                    if (node.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) node;
                        if (eElement.getElementsByTagName("azon").item(0).getTextContent().equals(Integer.toString(random_int))){
                      
                        output.write("                                      What does the following word mean?\n\n\n");
                        output.write("                                                              "); 
                        output.write(eElement.getElementsByTagName("word_2").item(0).getTextContent());

                        }
                    }
                }
            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
     
        RKiír Rk = new RKiír();
        Rk.RKi();
        
    }
}