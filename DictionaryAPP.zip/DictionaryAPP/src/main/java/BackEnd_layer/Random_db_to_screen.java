package BackEnd_layer;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class Random_db_to_screen {
    public static void main(String[] args) {
        RKiír Rk = new RKiír();
        Rk.RKi();
    }
}

class RKiír extends JFrame {
    public void RKi() {
        String sor;
        DefaultListModel < String > lm = new DefaultListModel < > ();
        JList < String > jl = new JList < > (lm);
        
        JScrollPane scroll = new JScrollPane(jl);
        scroll.setPreferredSize(new Dimension(500, 200));
        //setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocation(400, 300);
        
        //All_element_toTXTprinting.All_element_toTXTprinting_function();
        
        try (Scanner file = new Scanner(new File("system_files/db_to_scr.txt"))) {
            while (file.hasNext()) {
                sor = file.nextLine();
                lm.addElement(sor);
            }
            file.close();
        } catch (IOException error) {
            System.err.println("Error: " + error.getMessage());
        } finally {
            add(scroll);
            setTitle("Random word viewer");
            pack();
            setVisible(true);
        }
    }
}