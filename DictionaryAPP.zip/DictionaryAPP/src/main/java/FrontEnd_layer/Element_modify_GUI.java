package FrontEnd_layer;

import BackEnd_layer.Element_modify;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import static java.lang.Integer.parseInt;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Element_modify_GUI implements ActionListener{
    
    public static String elérési_út_mod = "";
    public static String mire_mod = "";
    
    public static String elérési_út_mod2 = "";
    public static String mire_mod2 = "";

    
    JFrame window1 = new JFrame("Modifying a transaction in the database");
    JTextField inputitemTextField = new JTextField();
    
    JTextField date2TextField = new JTextField();
    
    JTextField price2TextField = new JTextField("");
                
    
    JLabel inputitemLabel = new JLabel("Please enter the entry ID of the item to be modified:", JLabel.CENTER);
    //JLabel inputitem2Label = new JLabel("Amire módosítani szeretnéd:                     "
    //        + "-> Dátum : ", JLabel.RIGHT);
    
    JLabel date2Label = new JLabel("-> First language : ", JLabel.RIGHT);
    JLabel price2Label = new JLabel("-> Second language : ", JLabel.RIGHT);
    //JLabel description2Label = new JLabel("-> Leírás: ", JLabel.RIGHT);
    
    JButton signUpButton = new JButton("Modify");
    JLabel blank = new JLabel();
    FileWriter fileWriter;
    
    
    Element_modify_GUI() {
        
        GridLayout g1 = new GridLayout();
        //g1.setColumns(2);
        g1.setRows(4);
        
        window1.setLayout(g1);
        
        signUpButton.addActionListener(this);

        window1.add(inputitemLabel);
        window1.add(inputitemTextField);
        
        
        
        
        window1.add(date2Label); window1.add(date2TextField);
        window1.add(price2Label); window1.add(price2TextField);
        
        
        window1.add(blank);
        window1.add(signUpButton);
        
        window1.setSize(800,400);

        
        window1.setVisible(true);
    }   
    
    Properties properties = new Properties();
    @Override
    public void actionPerformed(ActionEvent ae) {
        
        if (ae.getActionCommand().equals(signUpButton.getActionCommand()))
        {
            try {
            
                elérési_út_mod = "//registration[azon='"+inputitemTextField.getText()+"']/word_1/text()";
                mire_mod = date2TextField.getText();
                
                //
                elérési_út_mod2 = "//registration[azon='"+inputitemTextField.getText()+"']/word_2/text()";
                mire_mod2 = price2TextField.getText();
                //
               
                Element_modify.Element_modify_funciton();
                
                Element_modify.Element_modify_funciton2();
                
            } catch (HeadlessException e) {
                JOptionPane.showMessageDialog(null, e+"");
            } catch (Exception ex) {
                Logger.getLogger(Element_modify_GUI.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
    }
}