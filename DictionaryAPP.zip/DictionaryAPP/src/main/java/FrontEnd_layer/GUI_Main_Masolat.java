package FrontEnd_layer;

import BackEnd_layer.RandomWord;
import Internet_layer.DriveQuickstart;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class GUI_Main_Masolat {
    public static void main(String[] args) throws IOException, GeneralSecurityException {
        Teszt t = new Teszt();
        t.teszt();
    }
}
class Teszt extends JFrame implements ActionListener {
    JFrame ablak = new JFrame();
    
    JButton A = new JButton("Add new word");
    JButton B = new JButton("Search in word database");
    JButton C = new JButton("Modify a registration (word)");
    JButton E = new JButton("See all words");
    
    JButton R = new JButton("Random word!");
    
    public void teszt() throws IOException, GeneralSecurityException {
        
        DriveQuickstart.keres();
        DriveQuickstart.letolt();
        DriveQuickstart.torol();
        
        GridLayout g1 = new GridLayout();
        g1.setColumns(1);
        g1.setRows(5);
        g1.setVgap(25); g1.setHgap(25);
        
        WindowListener exitListener = new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                final JOptionPane optionPane = new JOptionPane("Saving data...", JOptionPane.INFORMATION_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
                final JDialog dialog = new JDialog();
                dialog.setTitle("EXIT WINDOW");
                dialog.setModal(true);
                dialog.setContentPane(optionPane);
                dialog.setLocation(550, 275);
                dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
                dialog.pack();
                //create timer to dispose of dialog after 5 seconds
                Timer timer = new Timer(0, new AbstractAction() {
                    public void actionPerformed(ActionEvent ae) {
                        
                        try {
                            DriveQuickstart.keres();
                            DriveQuickstart.torol();
                            DriveQuickstart.feltolt();
                            
                            dialog.dispose();
                            
                        } catch (IOException ex) {
                            Logger.getLogger(Teszt.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (GeneralSecurityException ex) {
                            Logger.getLogger(Teszt.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                });
                timer.setRepeats(false);//the timer should only go off once
                //start timer to close JDialog as dialog modal we must start the timer before its visible
                timer.start();
                dialog.setVisible(true);
                
                File file = new File("program_database_dict.xml");
                if (file.delete()) {
                    System.out.println("File deleted successfully");
                } else {
                    System.out.println("Failed to delete the file");
                }
                ablak.setDefaultCloseOperation(EXIT_ON_CLOSE);
            }
        };
        ablak.addWindowListener(exitListener);


        ablak.setLayout(g1);
        ablak.setLocation(280, 125);
        ablak.setTitle(LAUNCHER.Main.ablakcím);
        
        ablak.add(A);
        ablak.add(C);
        //ablak.add(D);
        
        ablak.add(B);
        ablak.add(E);
        
        ablak.add(R);
        
        ablak.setSize(800, 500);
        ablak.setVisible(true);
        
        A.addActionListener(this);
        B.addActionListener(this);
        C.addActionListener(this);
        E.addActionListener(this);
        R.addActionListener(this);
    }
    @Override public void actionPerformed(ActionEvent e) {
        if (e.getSource() == A) {
            New_element a = new New_element();
            System.out.print(a);
        }
        else if (e.getSource() == B) {
            Element_printing_GUI el3 = new Element_printing_GUI();
            System.out.print(el3);
        }
        else if (e.getSource() == C) {
            Element_modify_GUI el2 = new Element_modify_GUI();
            System.out.print(el2);
        }
        else if (e.getSource() == E) {
            Kiír a = new Kiír();
            a.Ki();
        }
        else if (e.getSource() == R) {
            BackEnd_layer.RandomWord r = new RandomWord();
            try {
                r.RandomF();
            } catch (IOException ex) {
                Logger.getLogger(Teszt.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}