package FrontEnd_layer;

import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileWriter;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

enum Enum_combobox {
            B("Date"),
            C("First language"),
            D("Second language");
            public final String label;
            private Enum_combobox(String label){
                this.label = label;
            }
}

public class Element_printing_GUI implements ActionListener, ItemListener{
    
    JFrame window2 = new JFrame("Search in word database");
    public static String elérési_út = "ez nem az ám";
    
    JTextField inputitemTextField = new JTextField();
    JLabel inputitemLabel = new JLabel("Please enter the contained text: ", JLabel.CENTER);
    JLabel mitLabel = new JLabel("Please choose from the drop-down menu: ", JLabel.CENTER);
    JButton signUpButton = new JButton("Search");
    JLabel blank = new JLabel();
    FileWriter fileWriter;
    
    JComboBox < String > combo = new JComboBox < > ();
    
    
    Element_printing_GUI() {
        
        GridLayout g1 = new GridLayout();
        //g1.setColumns(2);
        g1.setRows(3);
        
        window2.setLayout(g1);
        
        signUpButton.addActionListener(this);
        
        window2.add(mitLabel);
        
        combo.addItem(Enum_combobox.B.label);
        combo.addItem(Enum_combobox.C.label);
        combo.addItem(Enum_combobox.D.label);
        
        window2.add(combo);
            
        window2.add(inputitemLabel);
        window2.add(inputitemTextField);
        
        window2.add(blank);
        
        window2.add(signUpButton);
        
        window2.setSize(600,300);

        
        
        window2.setVisible(true);
    }   
    
    Properties properties = new Properties();
    @Override
    public void actionPerformed(ActionEvent ae) {
        
        if (ae.getActionCommand().equals(signUpButton.getActionCommand()))
        {
            //String a = "";
            try {
                if (combo.getSelectedItem().equals(Enum_combobox.B.label)) {
                    elérési_út = "//registration[contains(date,'"+inputitemTextField.getText()+"')]/azon/text()";
                } 
                if (combo.getSelectedItem().equals(Enum_combobox.C.label)) {
                    elérési_út = "//registration[contains(word_1,'"+inputitemTextField.getText()+"')]/azon/text()";
                } 
                if (combo.getSelectedItem().equals(Enum_combobox.D.label)) {
                    elérési_út = "//registration[contains(word_2,'"+inputitemTextField.getText()+"')]/azon/text()";
                }

                try {
                    BackEnd_layer.Element_printing.Element_printing_function();
                    
                } catch (Exception ex) {
                    Logger.getLogger(Element_printing_GUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } catch (HeadlessException e) {
                JOptionPane.showMessageDialog(null, e+"");
            }
        }
    }

    @Override
    public void itemStateChanged(ItemEvent ie) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}