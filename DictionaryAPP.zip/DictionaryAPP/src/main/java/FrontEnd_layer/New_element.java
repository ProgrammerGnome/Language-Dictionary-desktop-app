package FrontEnd_layer;

import BackEnd_layer.New_element_to_node;
import Internet_layer.DriveQuickstart;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class New_element implements ActionListener{

    public static int fajlszamlalo = 0;
    
    JFrame window0 = new JFrame("Add words to database");
    
    JTextField word_1_TF = new JTextField("english");
    
    JTextField word_2_TF = new JTextField("deutsch");
        
    JLabel word_1_label = new JLabel("First language", JLabel.CENTER);
    
    JLabel word_2_label = new JLabel("Second language", JLabel.CENTER);
    
    JButton signUpButton = new JButton("Send");
    JLabel blank = new JLabel();
    FileWriter fileWriter;
    
    
    New_element() {
        
        GridLayout g1 = new GridLayout();
        //g1.setColumns(2);
        g1.setRows(3);
        
        window0.setLayout(g1);
        
        signUpButton.addActionListener(this);

        
        window0.add(word_1_TF);
        window0.add(word_2_TF);
        
        
        window0.add(word_1_label);
        window0.add(word_2_label);
        
        
        window0.add(blank);
        window0.add(signUpButton);
        
        window0.setSize(600,400);

        
        window0.setVisible(true);
    }   
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        
        if (ae.getActionCommand().equals(signUpButton.getActionCommand()))
        {
            try {
                
                Scanner scanner = new Scanner(new File("system_files/c_variable.txt"));
                while(scanner.hasNextInt())
                {
                    fajlszamlalo = scanner.nextInt();
                }

                fajlszamlalo = fajlszamlalo + 1;

                Writer wr = new FileWriter("system_files/c_variable.txt");
                wr.write(Integer.toString(fajlszamlalo));
                wr.close();
               
                SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
                Date date = new Date(System.currentTimeMillis());
                
                New_element_to_node.word_1 = word_1_TF.getText();
                
                New_element_to_node.date = formatter.format(date);
                
                New_element_to_node.word_2 = word_2_TF.getText();
                
                New_element_to_node.ERROR_nodetag_bovito();
                
                DriveQuickstart.keres();
                DriveQuickstart.torol();
                DriveQuickstart.feltolt();
                
            } catch (HeadlessException e) {
                JOptionPane.showMessageDialog(null, e+"");
            } catch (IOException ex) {
                Logger.getLogger(New_element.class.getName()).log(Level.SEVERE, null, ex);
            } catch (GeneralSecurityException ex) {
                Logger.getLogger(New_element.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
}